<?php

namespace App\CapitaineBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AppCapitaineBundle extends Bundle
{
}
